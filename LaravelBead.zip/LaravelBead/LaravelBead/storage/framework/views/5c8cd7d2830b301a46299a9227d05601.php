

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1 class="mb-5">Üdvözöljük a webhelyen!</h1>
        <div class="row">
            <div class="col-md-6">
                <a href="<?php echo e(route('matches.index')); ?>" class="btn btn-primary mb-3">Mérkőzések</a>
            </div>
            <div class="col-md-6">
                <a href="<?php echo e(route('teams.index')); ?>" class="btn btn-primary mb-3">Csapatok</a>
            </div>
            <div class="col-md-6">
                <a href="<?php echo e(route('table')); ?>" class="btn btn-primary mb-3">Tábla</a>
            </div>
            <div class="col-md-6">
                <a href="<?php echo e(route('favorites.index')); ?>" class="btn btn-primary mb-3">Kedvenceim</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\callm\OneDrive\Asztali gép\LaravelBead\LaravelBead\resources\views/site/home.blade.php ENDPATH**/ ?>