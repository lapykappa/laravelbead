<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Team;
use App\Models\Player;
use App\Models\Game;
use App\Models\Event;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
        // Create admin user
        User::create([
            'name' => 'Admin',
            'email' => 'admin@szerveroldali.hu',
            'password' => bcrypt('adminpwd'),
            'is_admin' => true,
        ]);

        // Create regular users
        User::factory(10)->create();

        // Create teams
        $teams = Team::factory(15)->create();

        // Create players for each team
        foreach ($teams as $team) {
            Player::factory(11)->create([
                'team_id' => $team->id,
            ]);
        }

        // Create games
        $now = now();
        Game::factory(10)->create([
            'start' => $now->copy()->addHours(1),
            'home_team_id' => $teams->random()->id,
            'away_team_id' => $teams->random()->id,
        ]);

        // Create finished games with events
        $finishedGame = Game::factory()->create([
            'start' => $now->copy()->subDays(1),
            'home_team_id' => $teams->random()->id,
            'away_team_id' => $teams->random()->id,
            'finished' => true,
        ]);

        $players = Player::inRandomOrder()->limit(22)->get();

        for ($i = 1; $i <= 90; $i += 10) {
            $event = Event::factory()->make([
                'game_id' => $finishedGame->id,
                'player_id' => $players->random()->id,
                'minute' => $i,
            ]);

            if ($event->type === 'gol' || $event->type === 'owngoal') {
                $event->extra = rand(0, 1) ? null : Player::inRandomOrder()->first()->id;
            }

            $event->save();
        }

        // Create ongoing game
        $ongoingGame = Game::factory()->create([
            'start' => $now->copy()->addMinutes(30),
            'home_team_id' => $teams->random()->id,
            'away_team_id' => $teams->random()->id,
        ]);

        // Create future game
        Game::factory()->create([
            'start' => $now->copy()->addDays(7),
            'home_team_id' => $teams->random()->id,
            'away_team_id' => $teams->random()->id,
        ]);
    }
}

