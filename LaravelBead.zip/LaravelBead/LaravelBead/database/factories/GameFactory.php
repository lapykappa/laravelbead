<?php

namespace Database\Factories;

use App\Models\Game;
use Illuminate\Database\Eloquent\Factories\Factory;

class GameFactory extends Factory
{
    protected $model = Game::class;

    public function definition()
    {
        return [
            'start' => $this->faker->dateTimeBetween('-7 days', '+7 days'),
            'finished' => $this->faker->boolean(75),
        ];
    }
}