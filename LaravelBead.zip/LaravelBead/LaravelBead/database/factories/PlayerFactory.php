<?php

namespace Database\Factories;

use App\Models\Player;
use Illuminate\Database\Eloquent\Factories\Factory;

class PlayerFactory extends Factory
{
    protected $model = Player::class;

    public function definition()
    {
        return [
            'name' => $this->faker->name,
            'number' => $this->faker->numberBetween(1, 99),
            'birthdate' => $this->faker->dateTimeBetween('-40 years', '-18 years')->format('Y-m-d'),
        ];
    }
}