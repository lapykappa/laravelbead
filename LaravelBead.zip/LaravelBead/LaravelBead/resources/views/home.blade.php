<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">

    <title>{{ config('app.name', 'Laravel') }}</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <a class="navbar-brand" href="#">Weboldal neve</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Mérkőzések</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Csapatok</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Táblázat</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Kedvencek</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12">
                <div class="jumbotron text-center">
                    <h1 class="display-4">Üdvözöljük a Weboldal nevén!</h1>
                    <p class="lead">Ez az oldal a sportrajongók számára készült.</p>
                    <hr class="my-4">
                    <p>Keresse meg a legfrissebb eredményeket, táblázatokat és kedvenc csapatai adatait.</p>
                    <a class="btn btn-primary btn-lg mt-3" href="#" role="button">Mérkőzések megtekintése</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}"></script>
</body>

</html>
